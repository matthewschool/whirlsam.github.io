# Add Debug Text of Dodge Position

1. Add the special `Play.render()` method
1. Put the `debug.text()` in it to print the `x` and `y` of `dodge`
