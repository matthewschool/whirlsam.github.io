# Add a Main Play State

1. Create a new `Play` class to represent the `Play` state
1. Create a `create()` method that prints something to console
1. Add it to the game as `Play` state
1. Start the `Play` state from the `Load` state

