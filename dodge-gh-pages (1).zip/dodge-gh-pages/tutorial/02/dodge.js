var game = new Phaser.Game(320,568);
