# Setup Phaser

1. Add a CDN script link to Phaser
1. Create a basic `dodge.js` script.
1. Add a script link to `dodge.js`
