# Moving the Thing to Dodge (without Physics)

1. Add a config `C` variable for `dodge` `speed`
1. Add math code to `Play.update()` moving `dodge` down like gravity

