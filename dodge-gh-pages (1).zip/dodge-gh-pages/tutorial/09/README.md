# Add Configuration Variables to the Top

1. Create a global variable in JSON format called `C`
1. Create a `C.bg.xspeed` variable
1. Create more variables for changeable values
1. Change the `index.html` background color to `black`
