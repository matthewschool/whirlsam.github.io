# Load Our Player Spritesheet

1. Load the `player.png` spritesheet in the `Load.preload()` method
1. Add config `C` variables for `file`, `width`, `height`, `frames`
