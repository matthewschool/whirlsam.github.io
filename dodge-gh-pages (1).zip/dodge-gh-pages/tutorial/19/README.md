# Resetting Dodge When It Falls Off Screen

1. Add logic to `Play.update()` to move `dodge` back to top
1. Change `C.d.starty` to -32 so it starts off the screen

