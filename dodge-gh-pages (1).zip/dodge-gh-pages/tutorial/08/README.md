# Make the Scrolling Background Image Appear

1. Add a `tileSprite` into `this.background` variable in `Play`
1. Set `autoScroll` on the background

