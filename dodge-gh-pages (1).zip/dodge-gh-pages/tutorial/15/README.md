# Understanding the Update Method

1. Add `Play.update()` method, (which is called 60 times a second)
1. To see this in action add `console.log("Update called.")`
1. Test it and watch from console
1. Remove it leaving `Play.update()` blank for next step

