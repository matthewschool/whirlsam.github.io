# Create GitHub Pages Site

1. Create a GitHub repo named the same as youraccount.github.io
1. Create a basic HTML home page: `index.html`
1. Create a sub directory for your game: `youraccount.github.io/dodge`
1. Create the HTML page for your game:
   `youraccount.github.io/dodge/index.html`
