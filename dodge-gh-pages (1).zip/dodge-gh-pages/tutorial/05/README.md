# Add A Load State

1. Create a `LoadState` class
1. Add the `Load` state to the game
1. Tell the `Boot` state to start `Load` state when done booting
1. Put `console.log("Loading...")` into the `Load.preload()` method
1. Put `console.log("Loaded")` into the `Load.create()` method
