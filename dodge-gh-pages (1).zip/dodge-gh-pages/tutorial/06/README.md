# Load a Background Image

1. Create an `assets` directory
1. Create a `background.png` file 320 wide and 568 or more high
1. Put a `background.png` file into `assets`
1. Add a `load.image()` method to the `Load.preload()` method

It won't show yet, just make sure there are no errors on the console.
