# Use Random Number Function to Change Dodge Starting Position

1. Set `dodge.x` to `randInt()` instead of `startx`
1. Note the edges
