# Create A Random Number Function

1. Create a `randInt(max)` function that returns a number between
   0 and `max`
1. Test your new function from the JavaScript console

* Note: Phaser has the `game.rnd.*` family of functions for dealing
  with random numbers built in. We create this function to learn
  JavaScript better since this is commonly needed in many JavaScript
  web applications that might not have Phaser

