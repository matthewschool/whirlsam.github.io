# Simplify By Adding Min and Max to Random Integer Function

1. Change the `randInt(max)` function to make a `min` as well
1. Use the new adjusted `max` with the `min` to set new random `x`
