# Add the Player Sprite to the Game

1. Add config `C` variables for `startx`, `starty`
1. Add the `sprite` in the `Play.create()` method 
1. Set the sprite `anchor` to 0.5 and 0.5
1. Set `smoothed` to `true` or `false` depending on image
1. Set `scale` to 1 or whatever works for your image
