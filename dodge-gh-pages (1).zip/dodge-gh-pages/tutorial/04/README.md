# Add Viewport Sizing

1. Add `meta` tag
1. Add `Boot` state
1. Add `preload()` callback method
1. Add `scaleMode`, `pageAlignHorizontally`, and `PageAlignVertically` 

