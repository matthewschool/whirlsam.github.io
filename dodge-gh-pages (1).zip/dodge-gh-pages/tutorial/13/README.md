# Add Animation to Your Player Sprite

1. Add a config `C` variable for `fps` speed
1. Add the `animation` to the `Play.create()` method
1. Turn on the animation with `play` in the same method
