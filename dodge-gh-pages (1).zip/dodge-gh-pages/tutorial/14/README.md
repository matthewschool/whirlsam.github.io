# Load and Add the Thing to Dodge

1. Follow steps 11-13 for `dodgeme.png`

