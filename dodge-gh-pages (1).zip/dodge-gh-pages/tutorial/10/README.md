# Add A Restart Convenience Function

1. Create a global function called `restart()` that start `Boot` state
